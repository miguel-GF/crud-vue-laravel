<?php $__env->startSection('content'); ?>

    <!-- MENU -->
    <nav class="navbar navbar-expand-md navbar-light nav-fondo">
        <div class="container-fluid">

            <a href="#" class="" data-toggle="modal" data-target="#ModalCambiarImagen">
                <img @change="mostrarImagen" :src="'storage/'+imagen"  width="75" height="50">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->

                <ul class="navbar-nav mr-auto">
                    <li><span class="tituloHome pr-4 pl-2"> | </span></li>
                    <li></li>
                    <li><span class="tituloHome">Gestor clientes</span></li>
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li>
                            <a class="text-white linkCerrarSesion" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">Cerrar sesión</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- debajo del menu -->
    <div class="container-fluid topHome">
            <div class="row ">
                <div class="col-md-4">
                    <span class="listadoClientes">Listado de clientes</span>
                </div>

                <div class="col-md-4">
                    <div v-if="mostrarInformacion" class="alert alert-success">
                        {{  informacion }}

                    </div>
                </div>

                <div class="col-md-4" align="right">
                    <button class="btn btn-success" @click="abrirAgregar()" >
                            Agregar nuevo cliente
                    </button>
                </div>
            </div>
    </div>

    <!--  BUSQUEDA  -->
    <form @submit.prevent="busquedaClientes">
        <div class="container-fluid busqueda">
            <div class="row">
                <div class="col-md-1">

                </div>

                <div class="col-md-1 text-justify text-sm-center">
                    <label class="pt-2">Búsqueda</label>
                </div>
                <div class="col-md-9">
                    <input v-model="busqueda" class="form-control rounded-0" type="text" placeholder="Nombre/Edad/Correo">
                </div>
                <div class="col-md-1" align="right">
                    <button class="btn btn-primary  btn-block">Buscar</button>
                </div>

            </div>
        </div>
    </form>

    <!-- IMAGEN -->
    <form method="POST" @submit.prevent="getImage" enctype="multipart/form-data">
        <div class="container-fluid">
            <div class="modal fade modal-open" id="ModalCambiarImagen" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content rounded-0 p-lg-3">
                        <div class="modal-header border-0 tituloModalCliente">
                            <span>Editar imagen</span>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>


                        <div class="modal-body" >
                            <div class="row">
                                <div class="col">
                                    <label>Selecciona una imagen</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="custom-file">
                                        <input accept="image/png, image/jpeg" @change="cambioImagen"
                                               name="imagen" type="file" class="custom-file-input" id="customFile">
                                        <label class="custom-file-label" for="customFile"></label>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="modal-footer border-0">
                            <button type="submit" class="btn btn-secondary btn btn-success" >Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div>
        <div class="container-fluid listado">

                <table class="table table-striped" @change:listarCliente="listarClientes">
                    <thead>
                    <tr class="table-active" >
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>CORREO ELECTRÓNICO</th>
                        <th>CATEGORIA</th>
                        <th>EDAD</th>
                        <th>OPCIONES</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr></tr>
                    <tr v-for="cliente in clientes" :key="cliente.id">
                        <td >
                            {{ cliente.id }}
                        </td>
                        <td >
                            {{ cliente.nombre_cliente }}
                        </td>
                        <td >
                            {{ cliente.email }}
                        </td>
                        <td >
                            {{ cliente.categoria }}
                        </td>
                        <td >
                            {{ cliente.edad }}
                        </td>
                        <td>
                            <a href="javascript:void(0)" @click="editarCliente(cliente)">Editar</a>
                            |
                            <a href="#" @click.prevent="borrarCliente(cliente.id)">Borrar</a>

                        </td>
                    </tr>
                    </tbody>
                </table>

        </div>
    </div>
    <editar-cliente-component @cambiar-info="cambiarInformacion" v-if="mostrarEdicion" :cliente="clienteEditar" />
    <agregar-cliente-component v-show="mostrarAgregar" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Escritorio/proyecto-final/resources/views/home.blade.php ENDPATH**/ ?>